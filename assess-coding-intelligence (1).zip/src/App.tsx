import React, { useState, useEffect } from 'react';
import { 
  Monitor, 
  Search, 
  LayoutGrid, 
  Settings, 
  Folder, 
  Trash2, 
  Terminal, 
  Globe, 
  ShoppingBag, 
  X, 
  Minus, 
  Square, 
  ShieldAlert, 
  AlertCircle, 
  Power,
  Play,
  FileText,
  RefreshCw,
  Plus,
  Cpu,
  Heart,
  Zap,
  HardDrive
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// --- Utils ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
type AppId = 'explorer' | 'trash' | 'store' | 'settings' | 'powershell' | 'powerpoint' | 'taskmanager' | 'ie' | 'roblox' | 'winws' | 'search';

interface WindowState {
  id: AppId;
  title: string;
  isOpen: boolean;
  isMaximized: boolean;
  zIndex: number;
}

interface DesktopItem {
  id: string;
  name: string;
  type: 'file' | 'folder' | 'app';
  icon: React.ReactNode;
  appId?: AppId;
}

// --- App ---
export default function Windows11() {
  const [windows, setWindows] = useState<WindowState[]>([]);
  const [activeApp, setActiveApp] = useState<AppId | null>(null);
  const [isStartOpen, setIsStartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isWinwsActive, setIsWinwsActive] = useState(false);
  const [installedApps, setInstalledApps] = useState<AppId[]>(['settings', 'powershell', 'powerpoint', 'taskmanager', 'ie', 'winws']);
  const [frozenApps, setFrozenApps] = useState<AppId[]>([]);
  const [isUacOpen, setIsUacOpen] = useState<{ open: boolean; appId: AppId | null }>({ open: false, appId: null });
  const [isSmartScreenOpen, setIsSmartScreenOpen] = useState(false);
  const [isErrorOpen, setIsErrorOpen] = useState<{ open: boolean; message: string } | null>(null);
  const [isBsod, setIsBsod] = useState(false);
  const [isLoveMode, setIsLoveMode] = useState(false);
  const [desktopItems, setDesktopItems] = useState<DesktopItem[]>([
    { id: '1', name: 'This PC', type: 'app', icon: <Monitor className="text-blue-500" />, appId: 'explorer' },
    { id: '2', name: 'Recycle Bin', type: 'app', icon: <Trash2 className="text-blue-400" />, appId: 'trash' },
    { id: '3', name: 'Microsoft Store', type: 'app', icon: <ShoppingBag className="text-orange-500" />, appId: 'store' },
    { id: '4', name: 'winws.exe', type: 'app', icon: <ShieldAlert className="text-red-500" />, appId: 'winws' },
  ]);
  const [time, setTime] = useState(new Date());
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; visible: boolean } | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const openWindow = (id: AppId, title: string) => {
    if (frozenApps.includes(id)) {
      setIsErrorOpen({ open: true, message: `Application ${title} is frozen and cannot be launched.` });
      return;
    }

    // Check for special blocked apps
    if (id === 'explorer' || id === 'trash') {
      setIsErrorOpen({ open: true, message: `System error: The file system is corrupted. Access to ${title} is denied.` });
      return;
    }

    if (id === 'ie') {
      setIsErrorOpen({ open: true, message: "Internet Explorer is no longer supported. Please use Microsoft Edge." });
      return;
    }

    if (id === 'roblox' && !isWinwsActive) {
      setIsErrorOpen({ open: true, message: "Roblox is not supported in your region. Error Code: 403" });
      return;
    }

    // Apps from Store/Desktop and Admin apps need UAC
    const adminApps: AppId[] = ['powershell', 'winws', 'taskmanager', 'roblox'];
    const isStoreApp = !['settings', 'explorer', 'trash', 'search'].includes(id);

    if (adminApps.includes(id) || (isStoreApp && id !== 'powerpoint')) {
      setIsUacOpen({ open: true, appId: id });
      return;
    }

    // Normal launch
    launchApp(id, title);
  };

  const launchApp = (id: AppId, title: string) => {
    setWindows(prev => {
      if (prev.find(w => w.id === id)) return prev;
      const maxZ = prev.length > 0 ? Math.max(...prev.map(w => w.zIndex)) : 10;
      return [...prev, { id, title, isOpen: true, isMaximized: false, zIndex: maxZ + 1 }];
    });
    setActiveApp(id);
    setIsStartOpen(false);
  };

  const handleUacResponse = (allowed: boolean) => {
    const appId = isUacOpen.appId;
    setIsUacOpen({ open: false, appId: null });
    
    if (allowed) {
      if (appId === 'winws') {
        setIsSmartScreenOpen(true);
      } else if (appId) {
        launchApp(appId, appId.toUpperCase());
      }
    } else {
      setIsErrorOpen({ open: true, message: "Access denied. Action cancelled by user." });
    }
  };

  const handleSmartScreen = (allowed: boolean) => {
    setIsSmartScreenOpen(false);
    if (allowed) {
      setIsWinwsActive(true);
      launchApp('winws', 'winws.exe - ACTIVE');
    }
  };

  const closeWindow = (id: AppId) => {
    setWindows(prev => prev.filter(w => w.id !== id));
    if (activeApp === id) setActiveApp(null);
  };

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY, visible: true });
  };

  const createFolder = () => {
    const newFolder: DesktopItem = {
      id: Math.random().toString(),
      name: 'New Folder',
      type: 'folder',
      icon: <Folder className="text-yellow-400 fill-yellow-400" />
    };
    setDesktopItems(prev => [...prev, newFolder]);
    setContextMenu(null);
  };

  if (isBsod) {
    return (
      <div className="fixed inset-0 bg-[#0078d7] text-white flex flex-col items-start justify-center p-20 font-sans cursor-none select-none z-[9999]">
        <div className="text-9xl mb-10">:(</div>
        <div className="text-2xl mb-8 leading-relaxed max-w-2xl">
          Your PC ran into a problem and needs to restart. We're just collecting some error info, and then we'll restart for you.
        </div>
        <div className="text-xl">100% complete</div>
        <div className="mt-12 flex gap-10">
          <div className="w-24 h-24 bg-white/20" />
          <div>
            <p>For more information about this issue and possible fixes, visit https://www.windows.com/stopcode</p>
            <p className="mt-4">If you call a support person, give them this info:</p>
            <p>Stop code: CRITICAL_PROCESS_DIED</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="h-screen w-screen overflow-hidden bg-cover bg-center select-none font-sans transition-all duration-700"
      style={{ backgroundImage: `url('https://images.unsplash.com/photo-1620121692029-d088224ddc74?auto=format&fit=crop&q=80&w=2560')` }}
      onClick={() => setContextMenu(null)}
      onContextMenu={handleContextMenu}
    >
      {/* Love Virus Effect */}
      {isLoveMode && (
        <div className="fixed inset-0 pointer-events-none z-[1000]">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ y: '110vh', x: Math.random() * 100 + 'vw', scale: 0 }}
              animate={{ y: '-10vh', scale: Math.random() * 2 + 1 }}
              transition={{ duration: Math.random() * 3 + 2, repeat: Infinity, delay: Math.random() * 5 }}
              className="absolute text-red-500 opacity-70"
            >
              <Heart fill="currentColor" size={40} />
            </motion.div>
          ))}
        </div>
      )}

      {/* Desktop Items */}
      <div className="p-4 grid grid-flow-col grid-rows-[repeat(auto-fill,100px)] gap-4 w-fit">
        {desktopItems.map(item => (
          <div 
            key={item.id}
            className="w-20 h-24 flex flex-col items-center justify-center gap-1 rounded hover:bg-white/10 active:bg-white/20 transition-colors group cursor-default"
            onDoubleClick={() => item.appId && openWindow(item.appId, item.name)}
          >
            <div className="text-3xl drop-shadow-md group-hover:scale-110 transition-transform">
              {item.icon}
            </div>
            <span className="text-white text-xs text-center drop-shadow-lg leading-tight px-1">
              {item.name}
            </span>
          </div>
        ))}
      </div>

      {/* Context Menu */}
      <AnimatePresence>
        {contextMenu?.visible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            style={{ top: contextMenu.y, left: contextMenu.x }}
            className="fixed w-64 bg-[#1c1c1c]/90 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl p-1 z-[5000] text-white text-sm"
          >
            <div className="px-3 py-2 hover:bg-white/10 rounded flex items-center gap-3" onClick={() => window.location.reload()}>
              <RefreshCw size={16} /> Refresh
            </div>
            <div className="h-px bg-white/10 my-1" />
            <div className="group relative">
              <div className="px-3 py-2 hover:bg-white/10 rounded flex items-center justify-between">
                <div className="flex items-center gap-3"><Plus size={16} /> New</div>
                <span>›</span>
              </div>
              <div className="hidden group-hover:block absolute left-full top-0 ml-1 w-48 bg-[#1c1c1c]/90 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl p-1">
                <div className="px-3 py-2 hover:bg-white/10 rounded flex items-center gap-3" onClick={createFolder}>
                  <Folder size={16} className="text-yellow-400" /> Folder
                </div>
                <div className="px-3 py-2 hover:bg-white/10 rounded flex items-center gap-3">
                  <FileText size={16} className="text-blue-400" /> Text Document
                </div>
              </div>
            </div>
            <div className="h-px bg-white/10 my-1" />
            <div className="px-3 py-2 hover:bg-white/10 rounded flex items-center gap-3">
              <Monitor size={16} /> Display settings
            </div>
            <div className="px-3 py-2 hover:bg-white/10 rounded flex items-center gap-3">
              <Settings size={16} /> Personalize
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Windows Manager */}
      <AnimatePresence>
        {windows.map(win => (
          <motion.div
            key={win.id}
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className={cn(
              "fixed bg-[#1c1c1c] border border-white/10 shadow-2xl overflow-hidden flex flex-col",
              win.isMaximized ? "inset-0" : "top-20 left-1/4 w-[800px] h-[500px] rounded-lg"
            )}
            style={{ zIndex: win.zIndex }}
            onMouseDown={() => setActiveApp(win.id)}
          >
            {/* Title Bar */}
            <div className="h-10 bg-black/20 flex items-center justify-between px-4 cursor-default">
              <div className="flex items-center gap-2 text-white/80 text-xs">
                {win.id === 'powershell' && <Terminal size={14} />}
                {win.id === 'store' && <ShoppingBag size={14} />}
                {win.id === 'powerpoint' && <FileText size={14} className="text-orange-500" />}
                <span>{win.title}</span>
              </div>
              <div className="flex h-full">
                <div className="w-12 h-full flex items-center justify-center hover:bg-white/10 transition-colors">
                  <Minus size={14} className="text-white" />
                </div>
                <div className="w-12 h-full flex items-center justify-center hover:bg-white/10 transition-colors">
                  <Square size={12} className="text-white" />
                </div>
                <div 
                  className="w-12 h-full flex items-center justify-center hover:bg-red-500 transition-colors"
                  onClick={() => closeWindow(win.id)}
                >
                  <X size={16} className="text-white" />
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-auto text-white">
              {win.id === 'powershell' && (
                <div className="p-4 font-mono text-sm">
                  <div className="text-blue-300">Windows PowerShell</div>
                  <div className="mb-4">Copyright (C) Microsoft Corporation. All rights reserved.</div>
                  <div className="flex gap-2">
                    <span className="text-green-400">PS C:\Users\Admin&gt;</span>
                    <span className="animate-pulse">_</span>
                  </div>
                </div>
              )}

              {win.id === 'store' && (
                <div className="p-6">
                  <div className="flex justify-between items-center mb-8">
                    <h1 className="text-2xl font-bold">Microsoft Store</h1>
                    <div className="bg-white/10 p-2 rounded-full px-4 text-xs">Search for apps...</div>
                  </div>
                  <div className="grid grid-cols-3 gap-6">
                    <div className="bg-white/5 rounded-xl p-4 hover:bg-white/10 border border-white/5 transition-all">
                      <div className="w-full aspect-square bg-blue-600 rounded-lg mb-4 flex items-center justify-center">
                        <Play size={40} />
                      </div>
                      <h3 className="font-semibold mb-1">Roblox</h3>
                      <p className="text-xs text-white/50 mb-4">Imagination Platform</p>
                      <button 
                        className="w-full bg-blue-600 py-1 rounded text-sm hover:bg-blue-500"
                        onClick={() => {
                          if (!installedApps.includes('roblox')) {
                            setInstalledApps(prev => [...prev, 'roblox']);
                            setDesktopItems(prev => [...prev, { id: 'roblox', name: 'Roblox', type: 'app', icon: <Play className="text-white bg-blue-600 p-1 rounded" />, appId: 'roblox' }]);
                            alert("Roblox has been added to desktop. Note: Launching it for the first time will trigger a security check.");
                          } else {
                            alert("Roblox is already installed.");
                          }
                        }}
                      >
                        {installedApps.includes('roblox') ? 'Installed' : 'Get'}
                      </button>
                    </div>

                    {[
                      { name: 'BSOD Simulator', icon: <Monitor />, action: () => setIsBsod(true) },
                      { name: 'Love Virus', icon: <Heart />, action: () => setIsLoveMode(true) },
                      { name: 'Fake Update', icon: <RefreshCw />, action: () => openWindow('search', 'Updating...') },
                      { name: 'Rickroll Pro', icon: <Globe />, action: () => window.open('https://www.youtube.com/watch?v=dQw4w9WgXcQ') },
                      { name: 'System Glitch', icon: <Zap />, action: () => document.body.classList.toggle('invert') }
                    ].map(prank => (
                      <div key={prank.name} className="bg-white/5 rounded-xl p-4 hover:bg-white/10 border border-white/5 transition-all">
                         <div className="w-full aspect-square bg-purple-600 rounded-lg mb-4 flex items-center justify-center">
                          {prank.icon}
                        </div>
                        <h3 className="font-semibold mb-1">{prank.name}</h3>
                        <p className="text-xs text-white/50 mb-4">Official Prank</p>
                        <button 
                          className="w-full bg-white/10 py-1 rounded text-sm hover:bg-white/20"
                          onClick={prank.action}
                        >
                          Run
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {win.id === 'winws' && (
                <div className="p-10 flex flex-col items-center justify-center h-full gap-6">
                  <ShieldAlert size={80} className={isWinwsActive ? "text-green-500" : "text-yellow-500"} />
                  <div className="text-center">
                    <h2 className="text-2xl font-bold mb-2">WinWS System Patcher</h2>
                    <p className="text-white/60">Status: {isWinwsActive ? "ACTIVE - System Patched" : "READY"}</p>
                  </div>
                  {!isWinwsActive && (
                    <button 
                      className="bg-red-600 hover:bg-red-700 px-8 py-2 rounded-full transition-colors"
                      onClick={() => setIsWinwsActive(true)}
                    >
                      ACTIVATE BYPASS
                    </button>
                  )}
                  {isWinwsActive && (
                    <div className="text-green-400 font-mono text-sm animate-pulse">
                      Regional locks removed. Roblox is now playable.
                    </div>
                  )}
                </div>
              )}

              {win.id === 'roblox' && (
                <div className="h-full bg-black flex flex-col items-center justify-center">
                  <img src="https://images.rbxcdn.com/f0980004925409391ef146e257c79e78.png" className="w-48 mb-8" alt="Roblox" />
                  <div className="text-2xl font-bold animate-pulse">LOADING GAME...</div>
                  <div className="mt-4 text-white/50">User: Admin_X</div>
                </div>
              )}

              {win.id === 'taskmanager' && (
                <div className="h-full bg-[#1c1c1c]">
                  <div className="p-4 border-b border-white/10 flex gap-6 text-sm">
                    <div className="border-b-2 border-blue-500 pb-2">Processes</div>
                    <div className="text-white/40">Performance</div>
                    <div className="text-white/40">App history</div>
                  </div>
                  <div className="p-2">
                    <table className="w-full text-left text-sm">
                      <thead className="text-white/40">
                        <tr>
                          <th className="p-2 font-normal">Name</th>
                          <th className="p-2 font-normal">Status</th>
                          <th className="p-2 font-normal">CPU</th>
                          <th className="p-2 font-normal">Memory</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          { name: 'System', status: 'Running', cpu: '0.1%', ram: '14 MB' },
                          { name: 'winws.exe', status: isWinwsActive ? 'Running' : 'Suspended', cpu: '4.5%', ram: '128 MB' },
                          { name: 'Microsoft Store', status: 'Running', cpu: '1.2%', ram: '312 MB' },
                          { name: 'Roblox Player', status: isWinwsActive ? 'Running' : 'Terminated', cpu: '22%', ram: '890 MB' },
                        ].map(p => (
                          <tr key={p.name} className="hover:bg-white/5">
                            <td className="p-2">{p.name}</td>
                            <td className="p-2">{p.status}</td>
                            <td className="p-2">{p.cpu}</td>
                            <td className="p-2">{p.ram}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {win.id === 'settings' && (
                <div className="h-full bg-[#1c1c1c] flex">
                  <div className="w-64 border-r border-white/10 p-4 flex flex-col gap-2">
                    <div className="flex items-center gap-3 p-2 bg-white/5 rounded"><Settings size={18}/> System</div>
                    <div className="flex items-center gap-3 p-2 hover:bg-white/5 rounded text-white/60"><Globe size={18}/> Network</div>
                    <div className="flex items-center gap-3 p-2 hover:bg-white/5 rounded text-white/60"><ShoppingBag size={18}/> Apps</div>
                    <div className="flex items-center gap-3 p-2 hover:bg-white/5 rounded text-white/60"><HardDrive size={18}/> Storage</div>
                  </div>
                  <div className="flex-1 p-8">
                    <h2 className="text-2xl font-bold mb-6">Installed Apps & Storage</h2>
                    <div className="grid gap-4">
                      {installedApps.map(appId => (
                        <div key={appId} className="bg-white/5 p-4 rounded-lg flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="text-2xl">
                              {appId === 'powershell' && <Terminal />}
                              {appId === 'powerpoint' && <FileText className="text-orange-500" />}
                              {appId === 'store' && <ShoppingBag className="text-orange-400" />}
                              {appId === 'winws' && <ShieldAlert className="text-red-500" />}
                              {appId === 'roblox' && <Play className="text-blue-500" />}
                              {appId === 'taskmanager' && <Cpu className="text-blue-400" />}
                              {appId === 'ie' && <Globe className="text-blue-600" />}
                            </div>
                            <div>
                              <div className="font-semibold">{appId.charAt(0).toUpperCase() + appId.slice(1)}</div>
                              <div className="text-xs text-white/40">Version 11.0.22621</div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button 
                              className={cn("px-4 py-1 rounded text-sm transition-colors", frozenApps.includes(appId) ? "bg-blue-600" : "bg-white/10 hover:bg-white/20")}
                              onClick={() => {
                                if (frozenApps.includes(appId)) {
                                  setFrozenApps(prev => prev.filter(a => a !== appId));
                                } else {
                                  setFrozenApps(prev => [...prev, appId]);
                                }
                              }}
                            >
                              {frozenApps.includes(appId) ? 'Unfreeze' : 'Freeze'}
                            </button>
                            <button 
                              className="px-4 py-1 bg-red-600/20 hover:bg-red-600/40 text-red-400 rounded text-sm transition-colors"
                              onClick={() => {
                                setInstalledApps(prev => prev.filter(a => a !== appId));
                                setDesktopItems(prev => prev.filter(item => item.appId !== appId));
                              }}
                            >
                              Uninstall
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* UAC Overlay */}
      <AnimatePresence>
        {isUacOpen.open && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[10000] flex items-center justify-center">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-[450px] bg-[#1f1f1f] rounded-lg border border-white/20 shadow-2xl overflow-hidden"
            >
              <div className="bg-blue-600 p-4 flex items-center gap-3 text-white">
                <ShieldAlert size={24} />
                <span className="font-semibold">User Account Control</span>
              </div>
              <div className="p-6 text-white">
                <h2 className="text-xl mb-4">Do you want to allow this app to make changes to your device?</h2>
                <div className="flex items-center gap-4 bg-white/5 p-3 rounded mb-6">
                  <div className="w-10 h-10 bg-white/10 rounded flex items-center justify-center">
                    <Cpu size={20} />
                  </div>
                  <div>
                    <div className="font-semibold">{isUacOpen.appId?.toUpperCase()}</div>
                    <div className="text-xs text-white/50">Verified publisher: Microsoft Windows</div>
                  </div>
                </div>
                <div className="flex gap-2 justify-end">
                  <button 
                    className="px-10 py-2 bg-blue-600 hover:bg-blue-500 rounded transition-colors"
                    onClick={() => handleUacResponse(true)}
                  >
                    Yes
                  </button>
                  <button 
                    className="px-10 py-2 bg-white/10 hover:bg-white/20 rounded transition-colors"
                    onClick={() => handleUacResponse(false)}
                  >
                    No
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SmartScreen Overlay */}
      <AnimatePresence>
        {isSmartScreenOpen && (
          <div className="fixed inset-0 bg-blue-700 z-[10001] p-20 text-white flex flex-col justify-center">
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="max-w-3xl"
            >
              <h1 className="text-5xl font-light mb-8">Windows protected your PC</h1>
              <p className="text-xl mb-12">Microsoft Defender SmartScreen prevented an unrecognized app from starting. Running this app might put your PC at risk.</p>
              
              <div className="flex flex-col gap-4">
                <div className="group cursor-pointer w-fit" onClick={() => {}}>
                  <span className="underline text-lg opacity-70 hover:opacity-100">More info</span>
                  <div className="mt-4 hidden group-active:block">
                    <p className="mb-2">App: winws.exe</p>
                    <p>Publisher: Unknown publisher</p>
                    <div className="flex gap-4 mt-8">
                      <button 
                        className="px-8 py-2 border border-white hover:bg-white/10"
                        onClick={() => handleSmartScreen(true)}
                      >
                        Run anyway
                      </button>
                      <button 
                        className="px-8 py-2 bg-white text-blue-700 hover:bg-white/90 font-semibold"
                        onClick={() => handleSmartScreen(false)}
                      >
                        Don't run
                      </button>
                    </div>
                  </div>
                </div>
                
                <button 
                  className="w-fit px-8 py-2 bg-white text-blue-700 hover:bg-white/90 font-semibold mt-4"
                  onClick={() => handleSmartScreen(false)}
                >
                  Don't run
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* System Error Dialog */}
      <AnimatePresence>
        {isErrorOpen?.open && (
          <div className="fixed inset-0 z-[11000] flex items-center justify-center">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-[400px] bg-[#2d2d2d] border border-white/20 shadow-2xl rounded text-white overflow-hidden"
            >
              <div className="bg-[#1f1f1f] px-3 py-1 flex justify-between items-center text-xs">
                <span>System Error</span>
                <X size={12} className="cursor-pointer" onClick={() => setIsErrorOpen(null)} />
              </div>
              <div className="p-6 flex gap-4">
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <AlertCircle size={30} />
                </div>
                <div>
                  <p className="text-sm leading-relaxed">{isErrorOpen.message}</p>
                  <div className="mt-6 flex justify-end">
                    <button 
                      className="px-8 py-1.5 bg-[#3e3e3e] hover:bg-[#4a4a4a] border border-white/10 rounded transition-colors text-sm"
                      onClick={() => setIsErrorOpen(null)}
                    >
                      OK
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Start Menu */}
      <AnimatePresence>
        {isStartOpen && (
          <motion.div
            initial={{ y: 500, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 500, opacity: 0 }}
            className="fixed bottom-14 left-1/2 -translate-x-1/2 w-[600px] h-[700px] bg-[#1c1c1c]/80 backdrop-blur-3xl border border-white/10 rounded-xl shadow-2xl p-8 z-[4000]"
          >
            <div className="relative mb-8">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={18} />
              <input 
                type="text" 
                placeholder="Type here to search" 
                className="w-full bg-black/30 border-b-2 border-blue-500/50 p-3 pl-12 rounded-lg text-white outline-none focus:bg-black/50"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
              />
            </div>

            <div className="mb-8 overflow-y-auto max-h-[400px]">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm font-semibold text-white">
                  {searchQuery ? 'Search Results' : 'Pinned'}
                </span>
                {!searchQuery && <button className="text-xs bg-white/5 px-2 py-1 rounded hover:bg-white/10">All apps ›</button>}
              </div>
              <div className="grid grid-cols-6 gap-y-6">
                {[
                  { name: 'Edge', icon: <Globe className="text-blue-400" />, id: 'ie' },
                  { name: 'PowerPoint', icon: <FileText className="text-orange-500" />, id: 'powerpoint' },
                  { name: 'Store', icon: <ShoppingBag className="text-orange-400" />, id: 'store' },
                  { name: 'Settings', icon: <Settings className="text-gray-400" />, id: 'settings' },
                  { name: 'Terminal', icon: <Terminal className="text-gray-200" />, id: 'powershell' },
                  { name: 'Task Manager', icon: <Cpu className="text-blue-500" />, id: 'taskmanager' },
                  { name: 'WinWS', icon: <ShieldAlert className="text-red-500" />, id: 'winws' },
                  { name: 'Roblox', icon: <Play className="text-blue-500" />, id: 'roblox' },
                ]
                .filter(app => !searchQuery || app.name.toLowerCase().includes(searchQuery.toLowerCase()))
                .map(app => (
                  <div 
                    key={app.name} 
                    className="flex flex-col items-center gap-2 group cursor-pointer"
                    onClick={() => {
                      if (app.id) openWindow(app.id as AppId, app.name);
                    }}
                  >
                    <div className="text-3xl group-hover:scale-110 transition-transform">{app.icon}</div>
                    <span className="text-[11px] text-white/80">{app.name}</span>
                  </div>
                ))}
              </div>
              {searchQuery && ![
                { name: 'Edge', id: 'ie' }, { name: 'PowerPoint', id: 'powerpoint' }, { name: 'Store', id: 'store' }, 
                { name: 'Settings', id: 'settings' }, { name: 'Terminal', id: 'powershell' }, { name: 'Task Manager', id: 'taskmanager' },
                { name: 'WinWS', id: 'winws' }, { name: 'Roblox', id: 'roblox' }
              ].some(app => app.name.toLowerCase().includes(searchQuery.toLowerCase())) && (
                <div className="text-center text-white/40 mt-10">No apps found matching "{searchQuery}"</div>
              )}
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-6 bg-black/20 flex justify-between items-center rounded-b-xl">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-xs">A</div>
                <span className="text-xs">Admin</span>
              </div>
              <Power size={18} className="text-white hover:text-blue-400 cursor-pointer" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Taskbar */}
      <div className="fixed bottom-0 left-0 right-0 h-12 bg-[#0f0f0f]/80 backdrop-blur-2xl flex items-center justify-between px-3 z-[5000] border-t border-white/5">
        <div className="flex-1" />
        
        <div className="flex items-center gap-1">
          <button 
            className={cn("p-2 rounded hover:bg-white/10 transition-colors", isStartOpen && "bg-white/10")}
            onClick={() => { setIsStartOpen(!isStartOpen); }}
          >
            <LayoutGrid size={22} className="text-blue-400" />
          </button>
          
          <button 
            className="p-2 rounded hover:bg-white/10 transition-colors"
            onClick={() => setIsStartOpen(true)}
          >
            <Search size={22} className="text-white" />
          </button>

          {windows.map(win => (
            <button 
              key={win.id}
              className={cn(
                "p-2 rounded hover:bg-white/10 transition-colors relative group",
                activeApp === win.id && "bg-white/10"
              )}
              onClick={() => setActiveApp(win.id)}
            >
              {win.id === 'powershell' && <Terminal size={22} className="text-white" />}
              {win.id === 'store' && <ShoppingBag size={22} className="text-orange-400" />}
              {win.id === 'powerpoint' && <FileText size={22} className="text-orange-500" />}
              {win.id === 'winws' && <ShieldAlert size={22} className="text-red-500" />}
              {win.id === 'roblox' && <Play size={22} className="text-blue-500" />}
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-blue-500 rounded-full scale-0 group-hover:scale-100 transition-transform" />
              {activeApp === win.id && (
                <div className="absolute -bottom-1 left-1.5 right-1.5 h-1 bg-blue-400 rounded-full" />
              )}
            </button>
          ))}
        </div>

        <div className="flex-1 flex justify-end items-center gap-4 text-white text-[11px]">
          <div className="flex items-center gap-2 hover:bg-white/10 p-1 px-2 rounded transition-colors">
            <Zap size={14} />
            <Globe size={14} />
            <HardDrive size={14} />
          </div>
          <div className="text-right leading-none hover:bg-white/10 p-1 px-2 rounded transition-colors">
            <div>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
            <div>{time.toLocaleDateString([], { day: '2-digit', month: '2-digit', year: 'numeric' })}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
